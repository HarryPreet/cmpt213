import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**Represent minions as a list
 */
public class MinionManager implements Iterable<Minion>{
    private List<Minion> Minions= new ArrayList<>();
    private int size;

    public MinionManager() {
        size=0;
    }

    public int getSize() {
        return size;
    }


    public void add(Minion m){
        Minions.add(m);
        size++;

    }

    public void remove(int m){
        Minions.remove(m);
        size--;
    }


    public void attribute(int a){
        Minion m = Minions.get(a);
        m.increaseAttribute();
    }

    @Override
    public Iterator<Minion> iterator() {
        return Minions.iterator();
    }
}
