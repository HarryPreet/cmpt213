import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Represents the UI of our program, displays a list of options
 * Allows user to choose among options, does the required action
 * Stores the the tile of our menu, and available options as strings
 */

public class TextMenu {
    private MinionManager manager;
    private String title;
    private List<String> options = new ArrayList<>();

    public TextMenu(MinionManager manager, String title, List<String> options) {
        this.manager = manager;
        this.title = title;
        this.options = options;
    }

    public void printOptions() {

        int size = options.size();
        for (int i = 0; i < size; i++) {
            System.out.println((i + 1) + ". " + options.get(i));
        }
    }

    public void printStars() {
        int n = title.length();
        for (int i = 0; i < n + 2; i++) {
            System.out.print("*");
        }
        System.out.println();

    }
    //Listing all minions

    public void listMinions() {
        int i = 1;
        for (Minion m : manager) {
            String index = Integer.toString(i);
            System.out.println(index + "." + m);
            ++i;
        }
    }

    //Selecting a valid minion

    public int minionSelection() {
        boolean valid = false;
        int minionSelected = 0;
        while (!valid) {
            System.out.println("Select Minion: ");
            Scanner in = new Scanner(System.in);
            minionSelected = in.nextInt();
            in.nextLine();
            if (minionSelected < 0) {
                System.out.println("Wrong Selection! Please Select Valid Minion! ");
            }
            if (minionSelected > manager.getSize()) {
                System.out.println("Wrong Selection! Please Select Valid Minion! ");
            } else {
                valid = true;
            }
        }
        return minionSelected - 1;
    }
    //Displaying the menu of options and doing the required actions
    public void show() {
        boolean isDone = false;
        while (!isDone) {
            printStars();
            System.out.println("*" + title + "*");
            printStars();
            printOptions();
            System.out.println(("ENTER OPTION: "));
            Scanner in = new Scanner(System.in);
            int choice = in.nextInt();
            in.nextLine();

            switch (choice) {
                case 1:
                    listMinions();
                    break;
                case 2:
                    System.out.println("Enter Name of Minion : ");
                    String name = in.nextLine();
                    System.out.println("Enter Height of Minion : ");
                    double height = in.nextDouble();
                    Minion m = new Minion(name, height, 0);
                    manager.add(m);
                    System.out.println("Minion Added ");
                    break;
                case 3:
                    if (manager.getSize() == 0) {
                        System.out.println("No Minions to Remove ");
                        break;
                    }
                    System.out.println("Remove Minion: ");
                    listMinions();
                    System.out.println("Enter 0 to Cancel ");
                    int minionToDelete = minionSelection();
                    if (minionToDelete == -1) {
                        System.out.println("Cancelled ");
                        break;
                    }
                    manager.remove(minionToDelete);
                    System.out.println("Minion Removed ");
                    break;
                case 4:
                    if (manager.getSize() == 0) {
                        System.out.println("No Minions to Attribute ");
                        break;
                    }
                    System.out.println("Select Minion to Attribute an Evil Deed: ");
                    listMinions();
                    int minionToAttribute = minionSelection();
                    System.out.println("Enter 0 to Cancel ");
                    if (minionToAttribute == -1) {
                        System.out.println("Cancelled ");
                        break;
                    }
                    manager.attribute(minionToAttribute);
                    System.out.println("Minion Attributed with Evil Deed ");
                    break;
                case 5:
                    if (manager.getSize() == 0) {
                        System.out.println("No Minions to Dump ");
                        break;
                    }
                    System.out.println("Minion Details: ");
                    for (Minion minion : manager) {
                        System.out.println(minion.toString());
                    }
                    break;
                case 6:
                    isDone = true;
                    break;
                default:
                    System.out.println("Error! Re-enter a valid value. ");
            }

        }
    }

}
