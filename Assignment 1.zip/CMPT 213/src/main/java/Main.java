import java.util.Arrays;

public class Main {

    public static  void main(String args[]) {
        //Create Model
        MinionManager manager = new MinionManager();
        String[] a = {"List", "Add", "Remove", "Attribute an Evil Deed", "Debug: Dump Minion Details", "Exit"};
        //Create UI
        TextMenu menu = new TextMenu(manager, "MENU", Arrays.asList(a));
        //Launch
        menu.show();

    }
}
