/**
 * Represent a minion's name, height and the number of evil deeds it has done
 *
 */

public class Minion {
    private String name;
    private double height;
    private int numberOfEvilDeeds;

    public Minion(String name, double height, int numberOfEvilDeeds) {
        this.name = name;
        this.height = height;
        this.numberOfEvilDeeds = numberOfEvilDeeds;
    }

    public String getName() {
        return name;
    }

    public double getHeight() {
        return height;
    }

    public int getNumberOfEvilDeeds() {
        return numberOfEvilDeeds;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void setNumberOfEvilDeeds(int numberOfEvilDeeds) {
        this.numberOfEvilDeeds = numberOfEvilDeeds;
    }
    public void increaseAttribute(){
        this.numberOfEvilDeeds=this.numberOfEvilDeeds+1;
    }

    @Override
    public String toString() {
        return "Minion: " +
                "Name= " + name + '\'' +
                ", Height= " + height +
                ", Number Of Evil Deeds=" + numberOfEvilDeeds +
                '}';
    }
}
